//
//  NSString+NUll.h
//  textDEemo
//
//  Created by 邹少军 on 16/8/16.
//  Copyright © 2016年 chengdian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NUll)

- (BOOL) isBlankString:(NSString *)string;

+ (BOOL)stringIsNull:(NSString *)stri;

@end
